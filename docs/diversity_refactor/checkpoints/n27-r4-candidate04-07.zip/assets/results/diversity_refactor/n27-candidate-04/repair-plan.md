# N2.7-R3: reusable leaf grammar with producer binding

Written before candidate source edits. Candidate04 only; no active apply.

Intake512: existing action grammar accepts only5 cases, and its intersection with
supported subject/garnish/direct template accepts only the old9/40/51. Background
and clothing expansion alone therefore cannot demonstrate broader application.
New actual targets41 (garage/bolt/hood) and458 (road/vending machine/separates)
exercise reusable constructions; their seed IDs must never enter runtime logic.

1. Lock new actual fixtures RED plus old two-sentence/relative-scope regressions.
2. Add a bounded shared noun-phrase grammar: explicit noun-head categories,
   modifier/compound tokens, determiners and finite structural connectors. Consume
   the whole string; unknown tokens/independent clauses fail closed. Reuse it for
   object, event, background and simple garment phrases, without an English-parser
   dependency or adding complete action strings to old accepted phrase tables.
3. Add productive action constructors (transitive gerund + determined object NP
   + optional spatial PP; stance + spatial artifact NP; limited reflexive/subordinate
   shared predicates; before/after/during event NP; directional gaze gerund). Retain
   old complex reviewed leaves only as compatibility fallback. Preserve complete
   action text and frame/surface/slot binding; do not treat heuristic ActionFrame
   fields as grammar proof. Render gaze garnish as a gerund, not with + gerund.
4. New background clauses require BOTH positive grammar and exact current producer
   field membership for the bound location pack (environment/core/props/time).
   Verify connectors and entire component sequences, not catalog keys alone.
   Reuse the owned relative-clause renderer; preserve modifier/mood ordering and
   time-first fallback. New simple clothing NPs must bind to actual producer choice
   combinations and pass the same nominal grammar; reject unproved detail/outerwear
   forms. Existing supported outputs remain compatible.
5. Keep action object/artifact/event heads distinct from place heads. Reject new
   action/place-anchor overlaps or unknown location relationships rather than
   retaining R1's blanket no-location-overlap rationale after expanding grammar.
6. Test unseen verb/NP/preposition/garment combinations, wrong producer fields,
   coherent unknown tails, independent subjects, overlaps, forged proof, frame and
   surface mismatches. No new public fields, upstream debug serialization, source
   vocabulary entries, numeric threshold changes or dependencies.
7. Demonstrate additional real clauses before freeze. Review, targeted regression,
   vocabulary/asset/static/full-flow checks, explicit source delta allowlist. Then
   own8192 reference/2048 gate + fixed80 quality and paired2048 observations using
   the unchanged source-bound V150 baseline. Record actual coverage and rejection
   honestly; six-family/entropy and all A1.6 adoption criteria remain in force.

This is a finite grammatical lexicon, not a seed/whole-prompt allowlist or blanket
catalog grammar approval. Wider English coverage and unproved placements remain
explicit limitations. Formal adoption is not implied by a few additional seeds.

## Pre-freeze review refinements

- Enforce NP order (determiner, adjectives, noun compounds, head), finite a/an
  agreement and plural restrictions; arbitrary token permutations are not proof.
- New background sequences must match the producer's max-one core/props/time
  structure and raw-segment deduplication; preserve its shuffled order.
- New source-bound location heads choose their explicit grammatical preposition:
  road/street -> on; garage/workshop/shop/bay/station -> in. Missing mappings fail
  closed. Raw evidence still verifies the original builder's in-prefixed string;
  only family-specific materialization corrects that grammar. Preserve existing
  R1 output bytes and selected location facts; test the actual458 road realization.
