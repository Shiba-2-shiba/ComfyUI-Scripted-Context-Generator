import argparse
import json
import sys
from collections import Counter
from datetime import datetime
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from workflow_widget_validation import load_workflow
from tools.workflow_prompt_runner import (
    build_canonical_record,
    derive_randomized_seed,
    execute_workflow,
)


RESULTS_ROOT = ROOT / "assets" / "results" / "workflow_diversity"
def ensure_dir(path: Path):
    path.mkdir(parents=True, exist_ok=True)


def execute_custom_workflow(workflow: dict, run_seed: int) -> dict:
    """Compatibility adapter for callers of the original diversity runner."""

    executed = execute_workflow(workflow, run_seed)
    return {
        "node_outputs": executed["node_outputs"],
        "execution_trace": executed["execution_trace"],
    }


def build_run_record(workflow: dict, run_seed: int) -> dict:
    canonical = build_canonical_record(workflow, run_seed)
    return {
        "run_seed": run_seed,
        "prompt": canonical["cleaned_prompt"],
        "raw_prompt": canonical["raw_prompt"],
        "summary_text": canonical["summary_text"],
        "context": canonical["context"],
        "execution_trace": canonical["execution_trace"],
    }


def top_items(counter: Counter, limit: int = 10) -> list[dict]:
    return [{"value": value, "count": count} for value, count in counter.most_common(limit)]


def summarize_records(records: list[dict]) -> dict:
    prompt_counter = Counter(record["prompt"] for record in records)
    character_counter = Counter(
        record["context"].get("extras", {}).get("character_name") or record["context"].get("subj", "")
        for record in records
    )
    location_counter = Counter(record["context"].get("loc", "") for record in records)
    action_counter = Counter(record["context"].get("action", "") for record in records)
    clothing_counter = Counter(record["context"].get("extras", {}).get("clothing_prompt", "") for record in records)
    location_prompt_counter = Counter(record["context"].get("extras", {}).get("location_prompt", "") for record in records)
    mood_counter = Counter(record["context"].get("meta", {}).get("mood", "") for record in records)
    signature_counter = Counter(
        (
            record["context"].get("extras", {}).get("character_name") or record["context"].get("subj", ""),
            record["context"].get("loc", ""),
            record["context"].get("action", ""),
            record["context"].get("meta", {}).get("mood", ""),
        )
        for record in records
    )
    warning_counter = Counter(
        warning
        for record in records
        for warning in record["context"].get("warnings", [])
    )
    scene_source_counter = Counter(
        history_item.get("decision", {}).get("selected_source", "unknown")
        for record in records
        for history_item in record["context"].get("history", [])
        if history_item.get("node") == "ContextSceneVariator"
    )

    prompt_lengths = [len(record["prompt"]) for record in records]
    unique_prompt_count = len(prompt_counter)
    run_count = len(records)

    return {
        "runs": run_count,
        "unique_prompts": unique_prompt_count,
        "unique_prompt_ratio": round(unique_prompt_count / run_count, 4) if run_count else 0.0,
        "unique_scene_signatures": len(signature_counter),
        "unique_locations": len(location_counter),
        "unique_actions": len(action_counter),
        "unique_clothing_prompts": len(clothing_counter),
        "unique_location_prompts": len(location_prompt_counter),
        "runs_with_warnings": sum(1 for record in records if record["context"].get("warnings")),
        "avg_prompt_length": round(sum(prompt_lengths) / run_count, 2) if run_count else 0.0,
        "min_prompt_length": min(prompt_lengths) if prompt_lengths else 0,
        "max_prompt_length": max(prompt_lengths) if prompt_lengths else 0,
        "top_characters": top_items(character_counter),
        "top_locations": top_items(location_counter),
        "top_actions": top_items(action_counter),
        "top_moods": top_items(mood_counter),
        "scene_variation_sources": top_items(scene_source_counter),
        "top_warnings": top_items(warning_counter),
        "top_prompt_duplicates": [
            {"prompt": prompt, "count": count}
            for prompt, count in prompt_counter.most_common(10)
        ],
        "top_scene_signatures": [
            {
                "character": signature[0],
                "location": signature[1],
                "action": signature[2],
                "mood": signature[3],
                "count": count,
            }
            for signature, count in signature_counter.most_common(10)
        ],
    }


def execute_records(
    workflow: dict,
    seed_start: int,
    runs: int,
    coverage_target_locations: int = 0,
    max_runs: int = 0,
) -> tuple[list[dict], list[dict]]:
    records = []
    seen_locations = set()
    coverage_progress = []

    if coverage_target_locations > 0:
        run_limit = max_runs if max_runs > 0 else max(runs, coverage_target_locations * 6)
    else:
        run_limit = runs

    for offset in range(run_limit):
        record = build_run_record(workflow, seed_start + offset)
        records.append(record)
        location = record["context"].get("loc", "")
        if location:
            seen_locations.add(location)
        coverage_progress.append(
            {
                "run": offset + 1,
                "seed": seed_start + offset,
                "unique_locations": len(seen_locations),
                "location": location,
            }
        )
        if coverage_target_locations > 0 and len(seen_locations) >= coverage_target_locations:
            break

    return records, coverage_progress


def write_outputs(records: list[dict], summary: dict, output_dir: Path):
    ensure_dir(output_dir)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    samples_path = output_dir / f"context_workflow_samples_{timestamp}.jsonl"
    summary_path = output_dir / f"context_workflow_summary_{timestamp}.json"

    with samples_path.open("w", encoding="utf-8") as handle:
        for record in records:
            handle.write(json.dumps(record, ensure_ascii=False) + "\n")

    summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    return samples_path, summary_path


def print_summary(summary: dict, samples_path: Path, summary_path: Path):
    print("Workflow diversity analysis")
    print("==========================")
    print(f"runs: {summary['runs']}")
    print(f"unique prompts: {summary['unique_prompts']} ({summary['unique_prompt_ratio']:.2%})")
    print(f"unique scene signatures: {summary['unique_scene_signatures']}")
    print(f"unique locations: {summary['unique_locations']}")
    print(f"unique actions: {summary['unique_actions']}")
    print(f"unique clothing prompts: {summary['unique_clothing_prompts']}")
    print(f"unique location prompts: {summary['unique_location_prompts']}")
    if summary.get("coverage_target_locations"):
        print(
            "location coverage target: "
            f"{summary['coverage_target_locations']} "
            f"(reached={summary['coverage_reached']}, "
            f"runs_to_target={summary['runs_to_target']})"
        )
    print(f"runs with warnings: {summary['runs_with_warnings']}")
    print(
        "prompt length: "
        f"avg={summary['avg_prompt_length']} min={summary['min_prompt_length']} max={summary['max_prompt_length']}"
    )

    def print_counter_block(label: str, items: list[dict], key_name: str = "value"):
        print("")
        print(label)
        for item in items[:5]:
            print(f"- {item[key_name]}: {item['count']}")

    print_counter_block("Top characters", summary["top_characters"])
    print_counter_block("Top locations", summary["top_locations"])
    print_counter_block("Top moods", summary["top_moods"])
    print_counter_block("Scene variation sources", summary["scene_variation_sources"])
    print_counter_block("Top warnings", summary["top_warnings"])
    print("")
    print(f"samples: {samples_path}")
    print(f"summary: {summary_path}")


def parse_args():
    parser = argparse.ArgumentParser(
        description="Execute ComfyUI-workflow-context.json in-process and analyze output diversity."
    )
    parser.add_argument(
        "--workflow",
        default=str(ROOT / "ComfyUI-workflow-context.json"),
        help="Path to the workflow JSON to analyze.",
    )
    parser.add_argument("--runs", type=int, default=150, help="Number of workflow executions.")
    parser.add_argument("--seed-start", type=int, default=0, help="Starting master seed.")
    parser.add_argument(
        "--coverage-target-locations",
        type=int,
        default=0,
        help="Continue running until this many unique raw locations are seen, or max-runs is hit.",
    )
    parser.add_argument(
        "--max-runs",
        type=int,
        default=0,
        help="Hard cap when using --coverage-target-locations. Defaults to max(runs, target*6).",
    )
    parser.add_argument(
        "--output-dir",
        default=str(RESULTS_ROOT),
        help="Directory for JSONL samples and summary JSON.",
    )
    return parser.parse_args()


def main():
    args = parse_args()
    workflow_path = Path(args.workflow)
    workflow = load_workflow(workflow_path)

    records, coverage_progress = execute_records(
        workflow,
        seed_start=args.seed_start,
        runs=args.runs,
        coverage_target_locations=args.coverage_target_locations,
        max_runs=args.max_runs,
    )
    summary = summarize_records(records)
    summary["workflow"] = str(workflow_path)
    summary["seed_start"] = args.seed_start
    summary["coverage_target_locations"] = args.coverage_target_locations
    summary["max_runs"] = args.max_runs
    summary["coverage_reached"] = (
        summary["unique_locations"] >= args.coverage_target_locations
        if args.coverage_target_locations > 0
        else False
    )
    summary["runs_to_target"] = (
        next(
            (
                item["run"]
                for item in coverage_progress
                if item["unique_locations"] >= args.coverage_target_locations
            ),
            None,
        )
        if args.coverage_target_locations > 0
        else None
    )
    summary["locations_seen"] = sorted(
        {record["context"].get("loc", "") for record in records if record["context"].get("loc", "")}
    )
    summary["location_coverage_progress"] = coverage_progress

    samples_path, summary_path = write_outputs(records, summary, Path(args.output_dir))
    print_summary(summary, samples_path, summary_path)


if __name__ == "__main__":
    main()
